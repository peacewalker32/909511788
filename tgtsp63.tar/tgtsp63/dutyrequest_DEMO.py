# from dutyrequest import notif
import telebot
from telebot import apihelper
import requests
from datetime import datetime, timedelta, date
from telebot import types
import sqlite3
import time
from testreq import database, database_change
import array

# database1 = sqlite3.connect('schedule.db')

bot = telebot.TeleBot('***********************************************')

first_line = array(int,[*************]) #сюда пойдут админов


step_com = 0                        #задание глобальных переменных
closed_inc = 0
forward_inc = 0
worked_inc = 0



daytime = "08:00"       #маркер начала дневной смены
nighttime = "20:00"     #маркер начала ночной смены
deepnight = "00:00"     #маркер смены текущей даты
day = datetime.now().day
now = datetime.now()
current_date = date.today()
current_date_form = current_date.strftime("%d.%m.%Y")       #приведение даты к виду общему с базой данных
current_time_form = now.strftime("%H:%M")                   #приведение времени к упрощенному виду
# current_time_form2 = now.strftime("%H:%M:%S")
date_delta = now + timedelta(days=-1)                       #задание дельты времени для корректного отображения текущих ответственных в ночную смену
date_delta_form = date_delta.strftime("%d.%m.%Y")           #приедение дельты к виду общему с базой данных



@bot.message_handler(commands=['help'])         #сообщением /help вызывается прописанная ниже инструкция использования бота
def help(message):
    bot.send_message(message.chat.id,
                     "1. Для вывода текущих ответственных менеджеров первой линии необходимо ввести команду /start, после в открывшемся окне нажать на кнопку текущий ответственный (вывести ответственного можно также вручную написав Текущий ответственный)."
                     "\n2. Для передачи смены следующему ответственному необходимо перейти в личный чат к боту CommSOC notification bot и там в предложенных кнопках выбрать Передача смены."
                     "\n3. Для удобства передачи смены (указания обработанных, закрытых, эскалированных инцидентов) можно воспользоваться кнопкой Итоги смены, находящейся в личном чате с ботом CommSOC notification bot.")



@bot.message_handler(commands=['start'])           #основной функционал бота. вызывается сообщением /start
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=3)           #вызов необходимого вида клавиатуры
    btn1 = types.KeyboardButton('Текущий ответственный')        # кнопка текущий ответственный
    btn2 = types.InlineKeyboardButton('Передача смены')         # кнопка передача смены
    btn3 = types.KeyboardButton('Итоги смены')                  # кнопка итоги смены
    if message.chat.id == ************:                           # указание местонахождения кнопок. соответственно кнопки 2 и 3 находятся в личном чате с ботом, кнопка "текущий ответственный" - в общем чате
        markup.add(btn1)                                        #
    elif message.chat.id != *************:                         #
        markup.add(btn2, btn3)                                  #
    bot.send_message(message.chat.id, "Добрый день! Информация о функционале бота достпуна по команде /help.", reply_markup=markup)


@bot.message_handler(content_types=['text'])
def func(message):
    global step_com
    if (message.text == "Текущий ответственный"):
        bot.send_message(message.chat.id, "На данный момент в смене: " + database())           #при отправке текста "текущий ответственный", скрипт возвращает значение, совпадающее с текущей датой и временными маркерами
        step_com = 0
    elif (message.text == "Передача смены"):
        step_com = 0
        bot.send_message(**************, "Ответственный сменился, пожалуйста передайте итоги смены следующему ответственному менеджеру. " + database_change())          #при отправке текста "передача смены", скрипт возвращает следующее значение в таблице
    elif (message.text == "Итоги смены"):
        global worked_inc, closed_inc, forward_inc
        bot.send_message(message.chat.id, "Сколько было обработано инцидентов за смену?")
        step_com = 1                                                                            # вызов глобальной переменной и её изменение после отправки сообщения о количестве обработанных инцидентов. после данного сообщения, скрипт запоминает значения отправленные пользователем и отдает их с финальным ответным сообщением.
    elif step_com == 1:                                                                         # после каждого полученного сообщения счетчик глобальной переменной увеличивается на 1
        worked_inc = int(message.text)
        #worked_inc = bot.register_next_step_handler(message, callback = int)
        step_com = 2
        bot.send_message(message.chat.id, "Сколько было эскалировано?")
    elif step_com == 2:
        forward_inc = int(message.text)
        #forward_inc = bot.register_next_step_handler(message, callback = int)
        step_com = 3
        bot.send_message(message.chat.id, "Сколько было закрыто?")
    elif step_com == 3:
        closed_inc = int(message.text)
        #closed_inc = bot.register_next_step_handler(message, callback = int)
        step_com = 0
        bot.send_message(message.chat.id, "Информация учтена, хорошего отдыха!")
        bot.send_message(**************, "За текущюю смену:\n Обработано - " + str(worked_inc) + ',\n Закрыто - ' + str(closed_inc) + ",\n Эскалировано - " + str(forward_inc))         # возвращает  текст (только численные значения) с итогами смены в корректном виде

bot.polling(none_stop=True)                                         #непрерывная работа бота



