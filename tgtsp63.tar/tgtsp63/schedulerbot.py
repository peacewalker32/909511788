import telebot
from telebot import apihelper
import requests
from datetime import datetime, timedelta, date
from telebot import types
import schedule
import time
from testreq import database

bot = telebot.TeleBot('*****************************************')


def notifday():
    bot.send_message(*****************, "Дневная смена завершена. Текущий ответственный:" + " " + database() )     #уведомление об окончании дневной смены и отправка следующего ответственного в соответствии с БД

def notifnight():
    bot.send_message(****************, "Ночная смена завершена. Текущий ответственный:" + " " + database() )      #уведомление об окончании ночной смены и отправка следующего ответственного в соответствии с БД
    
def sozvon():
    bot.send_message(**********************, "Коллеги, еженедельный созвон состоится через 15 минут")               #уведомление о еженедельном пятничном созвоне
schedule.every().day.at("08:00").do(notifday)                                                           #указание времени срабатывания уведомлений
schedule.every().day.at("20:00").do(notifnight)
schedule.every().friday.at("13:45").do(sozvon)
#schedule.every(2).seconds.do(notifday)
#schedule.every(4).seconds.do(notifnight)



while True:
    schedule.run_pending()
    time.sleep(1)


bot.polling(none_stop=True)